from pickle import load, dump

# загрузка базы данных
with open('nardis.dat', 'rb') as f:
    DB = load(f)
init = DB[0]
base = DB[1]

# замена названия лаборатории на 'иммунохроматография'
for item in base[2016]:
    if item[39]:
        item[39] = 'иммунохроматография'

# Изменение данных инициализации
init['Лаборатория'] = 'КДЛ КГБУЗ НД г. Комсомольска-на-Амуре'
init['Методы'] = ('газовая хроматография', 'иммунохроматография')

# Сохранение базы данных
with open('nardis.dat', 'wb') as f:
    DB = [init, base]
    dump(DB, f)
