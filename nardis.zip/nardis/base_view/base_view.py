from pickle import load


with open('nardis_real.dat', 'rb') as file:
    DB = load(file)
    init = DB[0]
    base = DB[1]

doctors = init['Врачи']
keys = [key for key, value in doctors.items() if value == 'admin']
print('* Пароль администратора:')
print(keys[0])  # пароль администратора

# объём базы
year = 2016
if year in base.keys():
    print('* Количество записей:')
    print(len(base[year]))
    print('* Последние клиенты:')
    for item in base[year][-10:]:
        print(item[2])  # последние клиенты
else:
    print('Год задан неверно.')

# отобразить варианты значений строк с индексом 39
if False:
    base = base[1]
    temp = set()
    for item in base[2016]:
        temp.add(item[39])
    print(temp)
